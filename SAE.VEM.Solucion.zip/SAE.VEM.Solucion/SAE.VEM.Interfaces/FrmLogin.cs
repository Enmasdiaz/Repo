﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SAE.VEM.Capas.Data;
using SAE.VEM.Capas.Data.Models;


namespace SAE.VEM.Interfaces
{
    public partial class FrmLogin : Form
    {



        public FrmLogin()
        {
            InitializeComponent();
        }
        
        private void FrmLogin_Load(object sender, EventArgs e)
        {

        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            clsBeEntidades entidadesModel = new clsBeEntidades();
            clsLnEntidades entidades = new clsLnEntidades();


            entidadesModel.UserNameEntidad = txtUsuario.Text;
            entidadesModel.PassworEntidad = txtPassword.Text;

            if(entidades.ObtenerUsuario(ref entidadesModel))
            {
                MessageBox.Show("Logeado Correcto");

            }
            else
            {
                MessageBox.Show("Usuario y/o Incorrectos");
            }


            //if (txtUsuario.Text = entidadesModel.UserNameEntidad)
            //FrmInicio form = new FrmInicio();
            //form.Show();
            //this.Hide();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            //FrmInicio form = new FrmInicio();
            //form.Show();
            //this.Close();
        }

        private void FrmLogin_FormClosed(object sender, FormClosedEventArgs e)
        {
            //FrmInicio form = new FrmInicio();
            //form.Show();
            //this.Close();
        }

        private void txtUsuario_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
