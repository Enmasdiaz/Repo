﻿using System.Configuration;
using System.Windows;
namespace SAE.VEM.Capas.Data
{
    public class ConexionDB
    {

        public static string stringConnection = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
        

    }
}
