using Microsoft.Data.SqlClient;
using System.Windows;
namespace SAE.VEM.Datos.Modelos
{

		public class clsBeGruposEntidades : ICloneable {

		private int mIdGrupoEntidad = 0;
		private string mDescripcion = "";
		private string mComentario = "";
		private string mEstatus = "";
		private bool mNoEliminable = false;
		private DateTime mFechaRegistro = DateTime.Now;

		public int IdGrupoEntidad {
			get {
				return mIdGrupoEntidad;
			}
			set {
				mIdGrupoEntidad = value;
			}
		}

		public String Descripcion {
			get {
				return mDescripcion;
			}
			set {
				mDescripcion = value;
			}
		}

		public String Comentario {
			get {
				return mComentario;
			}
			set {
				mComentario = value;
			}
		}

		public String Estatus {
			get {
				return mEstatus;
			}
			set {
				mEstatus = value;
			}
		}

		public Boolean NoEliminable {
			get {
				return mNoEliminable;
			}
			set {
				mNoEliminable = value;
			}
		}

		public DateTime FechaRegistro {
			get {
				return mFechaRegistro;
			}
			set {
				mFechaRegistro = value;
			}
		}

		clsBeGruposEntidades()
		{
		}

		clsBeGruposEntidades(ref int IdGrupoEntidad, string Descripcion, string Comentario, string Estatus, bool NoEliminable, DateTime FechaRegistro)
		{
			mIdGrupoEntidad = IdGrupoEntidad;
			mDescripcion = Descripcion;
			mComentario = Comentario;
			mEstatus = Estatus;
			mNoEliminable = NoEliminable;
			mFechaRegistro = FechaRegistro;
		}

		public object Clone() {
			return base.MemberwiseClone();
		}

	}
}
