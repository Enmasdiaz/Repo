﻿using Microsoft.Data.SqlClient;
using System.Windows;
namespace SAE.VEM.Capas.Data
{
    public class ConexionDB
    {
        private SqlConnection Conexion ;
        private String ConnectionString;


        public void Con()
        {
            try
            {
                ConnectionString = @"Data Source=.;Initial Catalog=SellPoint; Integrated Security=true";
                Conexion = new SqlConnection(ConnectionString);
                Conexion.Open();
            }
            catch (Exception ex)
            {

                //MessageBox.Show("Error en la Conexion a la Base de datos", ex.Message);
            }
        }

    }
}
